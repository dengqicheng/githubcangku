package org.example.widgets;

import org.example.R;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;
import android.widget.TextView;

public class TagTextView extends TextView {
    private static final int DEFAULT_BORDER_WIDTH = 0;
    private static final int DEFAULT_RADIUS_SIZE = 0;
    private static final int DEFAULT_BORDER_COLOR = Color.BLACK;
    private float mRadius;
    private ColorStateList mBorderColor = ColorStateList.valueOf(DEFAULT_BORDER_COLOR);
    private float mBorderWidth = DEFAULT_BORDER_WIDTH;
    public TagTextView(Context context) {
        this(context, null);
    }

    public TagTextView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public TagTextView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        TypedArray ta = context.getTheme().obtainStyledAttributes(attrs, R.styleable.TagTextView, defStyleAttr, 0);

        mRadius = ta.getDimensionPixelSize(R.styleable.TagTextView_border_radius, DEFAULT_RADIUS_SIZE);
        ta.recycle();
        init();
    }

    /**
     * 初始化View
     *
     * @throws IllegalStateException
     */
    @SuppressWarnings("deprecation")
    private void init() {
        // 关闭硬件加速，否则会导致Xfermode混合成的透明背景为黑色
        if (android.os.Build.VERSION.SDK_INT >= 11) {
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (mRadius > 0) {
            Bitmap bitmap = generateMaskBitmap();
            Paint bitmapPaint = new Paint();
            bitmapPaint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_IN));
            canvas.drawBitmap(bitmap, 0f, 0f, bitmapPaint);
            bitmap.recycle();
        }
        // 画边框
        if (mBorderWidth > 0) {
            Paint borderPaint = new Paint();
            borderPaint.setStyle(Paint.Style.STROKE);
            borderPaint.setAntiAlias(true);
            borderPaint.setColor(mBorderColor.getColorForState(getDrawableState(), DEFAULT_BORDER_COLOR));
            borderPaint.setStrokeWidth(mBorderWidth);
            RectF borderRect = new RectF(0, 0, getWidth(), getHeight());
            // 向内偏移边框的位置，否则会超出画布
            borderRect.inset(mBorderWidth / 2, mBorderWidth / 2);
            canvas.drawRoundRect(borderRect, mRadius, mRadius, borderPaint);
        }
    }

    /**
     * 生成一张圆角矩形的掩盖图片
     *
     * @return Bitmap
     */
    public Bitmap generateMaskBitmap() {
        Bitmap bitmap = Bitmap.createBitmap(getWidth(), getHeight(), Bitmap.Config.ARGB_8888);
        Canvas bitmapCanvas = new Canvas(bitmap);
        RectF r = new RectF(0, 0, getWidth(), getHeight());
        Rect rect = new Rect(0, 0, getWidth(), getHeight());
        Paint bitmapPaint = new Paint();
        bitmapPaint.setAlpha(0);
        bitmapPaint.setColor(Color.TRANSPARENT);
        bitmapCanvas.drawRect(rect, bitmapPaint);
        bitmapPaint.reset();
        bitmapPaint.setStyle(Paint.Style.FILL);
        bitmapPaint.setAntiAlias(true);
        bitmapPaint.setColor(Color.WHITE);
        bitmapCanvas.drawRoundRect(r, mRadius, mRadius, bitmapPaint);
        return bitmap;
    }

    /**
     * 设置边框的颜色
     *
     * @param colors
     */
    public void setBorderColor(ColorStateList colors) {
        if (mBorderColor.equals(colors)) {
            return;
        }

        if (mBorderWidth > 0) {
            invalidate();
        }
    }
}
